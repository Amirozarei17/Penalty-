# -*- coding: utf-8 -*-
"""
ماژول دیتابیس (SQLite) برای ذخیره امتیاز بازیکنان
"""

import sqlite3
import os
import threading

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "scores.db")
_lock = threading.Lock()


def init_db():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS players (
                user_id INTEGER PRIMARY KEY,
                username TEXT,
                first_name TEXT,
                shoot_score INTEGER DEFAULT 0,
                shoot_played INTEGER DEFAULT 0,
                shoot_best_streak INTEGER DEFAULT 0,
                shoot_current_streak INTEGER DEFAULT 0,
                save_score INTEGER DEFAULT 0,
                save_played INTEGER DEFAULT 0,
                save_best_streak INTEGER DEFAULT 0,
                save_current_streak INTEGER DEFAULT 0
            )
        """)
        conn.commit()


def _ensure_player(conn, user_id, username, first_name):
    conn.execute(
        "INSERT OR IGNORE INTO players (user_id, username, first_name) VALUES (?, ?, ?)",
        (user_id, username, first_name),
    )
    conn.execute(
        "UPDATE players SET username = ?, first_name = ? WHERE user_id = ?",
        (username, first_name, user_id),
    )


def record_round(user_id, username, first_name, mode, won):
    """
    mode: 'shoot' یا 'save'
    won: True اگر بازیکن امتیاز گرفت (گل زد یا سیو کرد)
    خروجی: (score, played, current_streak, best_streak)
    """
    with _lock, sqlite3.connect(DB_PATH) as conn:
        _ensure_player(conn, user_id, username, first_name)
        score_col = f"{mode}_score"
        played_col = f"{mode}_played"
        cur_col = f"{mode}_current_streak"
        best_col = f"{mode}_best_streak"

        row = conn.execute(
            f"SELECT {score_col}, {played_col}, {cur_col}, {best_col} FROM players WHERE user_id = ?",
            (user_id,),
        ).fetchone()
        score, played, cur_streak, best_streak = row

        played += 1
        if won:
            score += 1
            cur_streak += 1
            best_streak = max(best_streak, cur_streak)
        else:
            cur_streak = 0

        conn.execute(
            f"UPDATE players SET {score_col} = ?, {played_col} = ?, {cur_col} = ?, {best_col} = ? "
            f"WHERE user_id = ?",
            (score, played, cur_streak, best_streak, user_id),
        )
        conn.commit()
        return score, played, cur_streak, best_streak


def get_player_stats(user_id):
    with sqlite3.connect(DB_PATH) as conn:
        row = conn.execute(
            """SELECT shoot_score, shoot_played, shoot_best_streak,
                      save_score, save_played, save_best_streak
               FROM players WHERE user_id = ?""",
            (user_id,),
        ).fetchone()
        if not row:
            return {
                "shoot_score": 0, "shoot_played": 0, "shoot_best_streak": 0,
                "save_score": 0, "save_played": 0, "save_best_streak": 0,
            }
        keys = ["shoot_score", "shoot_played", "shoot_best_streak",
                "save_score", "save_played", "save_best_streak"]
        return dict(zip(keys, row))


def get_leaderboard(mode, limit=10):
    """برترین بازیکنان بر اساس امتیاز یک حالت خاص"""
    score_col = f"{mode}_score"
    played_col = f"{mode}_played"
    with sqlite3.connect(DB_PATH) as conn:
        rows = conn.execute(
            f"""SELECT username, first_name, {score_col}, {played_col}
                FROM players
                WHERE {played_col} > 0
                ORDER BY {score_col} DESC, {played_col} ASC
                LIMIT ?""",
            (limit,),
        ).fetchall()
    return rows


def get_combined_leaderboard(limit=10):
    """برترین بازیکنان بر اساس مجموع امتیاز هر دو حالت"""
    with sqlite3.connect(DB_PATH) as conn:
        rows = conn.execute(
            """SELECT username, first_name, (shoot_score + save_score) AS total,
                      (shoot_played + save_played) AS played
               FROM players
               WHERE played > 0
               ORDER BY total DESC, played ASC
               LIMIT ?""",
            (limit,),
        ).fetchall()
    return rows
