# -*- coding: utf-8 -*-
"""
ماژول تولید گرافیک بازی پنالتی
با استفاده از Pillow صحنه‌های زیبا و حرفه‌ای از ضربات پنالتی می‌سازد.
"""

import os
import math
import random
from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageOps

WIDTH, HEIGHT = 1000, 700
FONT_DIR = "/usr/share/fonts/truetype/dejavu"
FONT_BOLD = os.path.join(FONT_DIR, "DejaVuSans-Bold.ttf")
FONT_REGULAR = os.path.join(FONT_DIR, "DejaVuSans.ttf")

ASSETS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets")
os.makedirs(ASSETS_DIR, exist_ok=True)

ZONES = ["left", "center", "right"]
ZONE_FA = {"left": "چپ", "center": "وسط", "right": "راست"}

# ---------------------------------------------------------------------------
# ابزارهای کمکی رسم
# ---------------------------------------------------------------------------

def _font(path, size):
    try:
        return ImageFont.truetype(path, size)
    except Exception:
        return ImageFont.load_default()


def _vertical_gradient(draw, box, color_top, color_bottom):
    x0, y0, x1, y1 = box
    height = y1 - y0
    for i in range(height):
        t = i / max(height - 1, 1)
        r = int(color_top[0] + (color_bottom[0] - color_top[0]) * t)
        g = int(color_top[1] + (color_bottom[1] - color_top[1]) * t)
        b = int(color_top[2] + (color_bottom[2] - color_top[2]) * t)
        draw.line([(x0, y0 + i), (x1, y0 + i)], fill=(r, g, b))


def _draw_soft_shadow(base_img, box, radius=18, opacity=90):
    shadow = Image.new("RGBA", base_img.size, (0, 0, 0, 0))
    sd = ImageDraw.Draw(shadow)
    sd.ellipse(box, fill=(0, 0, 0, opacity))
    shadow = shadow.filter(ImageFilter.GaussianBlur(radius))
    base_img.alpha_composite(shadow)


def _draw_pitch(draw, img):
    """چمن با راه‌راه‌های حرفه‌ای + پرسپکتیو ساده"""
    _vertical_gradient(draw, (0, 0, WIDTH, HEIGHT), (34, 139, 34), (20, 90, 24))

    # راه‌راه‌های چمن (پرسپکتیو - نوارهای مورب که پهن‌تر می‌شوند)
    stripe_count = 10
    for i in range(stripe_count):
        if i % 2 == 0:
            continue
        top_x0 = WIDTH * (i / stripe_count)
        top_x1 = WIDTH * ((i + 1) / stripe_count)
        # کشیدگی به سمت پایین برای حس پرسپکتیو
        bottom_x0 = top_x0 - 60
        bottom_x1 = top_x1 + 60
        draw.polygon(
            [(top_x0, 230), (top_x1, 230), (bottom_x1, HEIGHT), (bottom_x0, HEIGHT)],
            fill=(28, 120, 32, 255),
        )


def _draw_goal(draw, img):
    """دروازه با تور سه‌بعدی‌نما"""
    post_color = (250, 250, 250)
    post_dark = (200, 200, 200)

    left_x, right_x = 130, 870
    top_y = 90
    ground_y = 420
    depth_x, depth_y = 55, -35  # عمق تور به سمت داخل و بالا

    # تور پس‌زمینه (عمق)
    net_back = [
        (left_x + depth_x, top_y + depth_y),
        (right_x + depth_x, top_y + depth_y),
        (right_x + depth_x, ground_y + depth_y * 0.3),
        (left_x + depth_x, ground_y + depth_y * 0.3),
    ]
    draw.polygon(net_back, fill=(235, 235, 235, 255))

    # الگوی تور (خطوط شبکه) روی سقف و پس‌زمینه
    for gx in range(0, 13):
        x = left_x + depth_x + (right_x - left_x) * gx / 12
        draw.line([(x, top_y + depth_y), (x, ground_y + depth_y * 0.3)],
                   fill=(200, 200, 200), width=1)
    for gy in range(0, 8):
        y = top_y + depth_y + (ground_y + depth_y * 0.3 - top_y - depth_y) * gy / 7
        draw.line([(left_x + depth_x, y), (right_x + depth_x, y)],
                   fill=(200, 200, 200), width=1)

    # سقف عمق (تور بالا)
    roof = [
        (left_x, top_y), (right_x, top_y),
        (right_x + depth_x, top_y + depth_y), (left_x + depth_x, top_y + depth_y),
    ]
    draw.polygon(roof, fill=(225, 225, 225, 255))
    for gx in range(0, 13):
        x0 = left_x + (right_x - left_x) * gx / 12
        x1 = x0 + depth_x
        draw.line([(x0, top_y), (x1, top_y + depth_y)], fill=(195, 195, 195), width=1)

    # دیواره‌های کناری تور
    left_side = [(left_x, top_y), (left_x + depth_x, top_y + depth_y),
                 (left_x + depth_x, ground_y + depth_y * 0.3), (left_x, ground_y)]
    draw.polygon(left_side, fill=(215, 215, 215, 255))
    right_side = [(right_x, top_y), (right_x + depth_x, top_y + depth_y),
                  (right_x + depth_x, ground_y + depth_y * 0.3), (right_x, ground_y)]
    draw.polygon(right_side, fill=(215, 215, 215, 255))

    # تیرک‌ها (جلو) با سایه برای حس سه‌بعدی
    post_w = 12
    draw.rectangle([left_x - post_w, top_y - post_w, left_x + post_w, ground_y], fill=post_dark)
    draw.rectangle([left_x - post_w + 3, top_y - post_w, left_x + post_w - 3, ground_y], fill=post_color)

    draw.rectangle([right_x - post_w, top_y - post_w, right_x + post_w, ground_y], fill=post_dark)
    draw.rectangle([right_x - post_w + 3, top_y - post_w, right_x + post_w - 3, ground_y], fill=post_color)

    draw.rectangle([left_x - post_w, top_y - post_w, right_x + post_w, top_y + post_w], fill=post_dark)
    draw.rectangle([left_x - post_w, top_y - post_w + 3, right_x + post_w, top_y + post_w - 3], fill=post_color)

    # خط دروازه روی زمین
    draw.line([(left_x - 20, ground_y), (right_x + 20, ground_y)], fill=(255, 255, 255), width=5)

    # محوطه جریمه (خطوط سفید کوچک زمین)
    box_left, box_right = left_x - 90, right_x + 90
    box_top = ground_y - 15
    draw.line([(box_left, ground_y), (box_left, box_top)], fill=(255, 255, 255), width=4)
    draw.line([(box_right, ground_y), (box_right, box_top)], fill=(255, 255, 255), width=4)
    draw.line([(box_left, box_top), (box_right, box_top)], fill=(255, 255, 255), width=4)

    return left_x, right_x, top_y, ground_y


def _zone_center(zone, left_x, right_x, y):
    third = (right_x - left_x) / 3
    if zone == "left":
        x = left_x + third * 0.5
    elif zone == "right":
        x = right_x - third * 0.5
    else:
        x = (left_x + right_x) / 2
    return x, y


def _draw_ball(img, draw, pos, radius=26, mid_air=True):
    x, y = pos
    if mid_air:
        _draw_soft_shadow(img, (x - radius * 0.8, y + radius * 1.6, x + radius * 0.8, y + radius * 2.1),
                           radius=8, opacity=120)
    # توپ با گرادیان کروی ساده
    ball = Image.new("RGBA", (radius * 4, radius * 4), (0, 0, 0, 0))
    bd = ImageDraw.Draw(ball)
    bbox = (radius, radius, radius * 3, radius * 3)
    bd.ellipse(bbox, fill=(250, 250, 250, 255))
    # پنج‌ضلعی‌های کلاسیک توپ فوتبال (ساده‌شده)
    cx, cy = radius * 2, radius * 2
    bd.ellipse((cx - radius * 0.35, cy - radius * 0.35, cx + radius * 0.35, cy + radius * 0.35),
               fill=(30, 30, 30, 255))
    for ang in range(0, 360, 72):
        rad = math.radians(ang)
        px = cx + math.cos(rad) * radius * 0.62
        py = cy + math.sin(rad) * radius * 0.62
        bd.ellipse((px - 7, py - 7, px + 7, py + 7), fill=(30, 30, 30, 255))
    # سایه‌روشن برای حس حجم
    highlight = Image.new("RGBA", ball.size, (0, 0, 0, 0))
    hd = ImageDraw.Draw(highlight)
    hd.ellipse((radius * 0.9, radius * 0.7, radius * 1.9, radius * 1.6), fill=(255, 255, 255, 90))
    ball.alpha_composite(highlight)
    ball = ball.filter(ImageFilter.SMOOTH)
    img.alpha_composite(ball, (int(x - radius * 2), int(y - radius * 2)))


def _draw_keeper(img, draw, zone, left_x, right_x, ground_y, dive=True):
    """دروازه‌بان به صورت شکل انسانی ساده اما با حالت شیرجه پویا"""
    cx, base_y = _zone_center(zone, left_x, right_x, ground_y - 110)
    kw, kh = 90, 150
    layer = Image.new("RGBA", (kw * 2, kh * 2), (0, 0, 0, 0))
    kd = ImageDraw.Draw(layer)
    ox, oy = kw, kh * 1.1

    jersey = (255, 200, 0)
    shorts = (20, 20, 20)
    skin = (222, 178, 140)

    if dive and zone != "center":
        direction = -1 if zone == "left" else 1
        # بدن به صورت افقی (شیرجه)
        kd.ellipse((ox - 60, oy - 22, ox + 60 * direction * 1.3, oy + 22), fill=jersey)
        # سر
        kd.ellipse((ox + 55 * direction, oy - 26, ox + 95 * direction, oy + 14), fill=skin)
        # دست‌ها کشیده به سمت توپ
        kd.line([(ox + 30 * direction, oy - 10), (ox + 110 * direction, oy - 45)], fill=jersey, width=16)
        kd.ellipse((ox + 100 * direction, oy - 60, ox + 130 * direction, oy - 30), fill=skin)
        # پاها
        kd.line([(ox - 55, oy + 5), (ox - 95, oy + 35)], fill=shorts, width=18)
    else:
        # حالت ایستاده وسط، آماده
        kd.ellipse((ox - 22, oy - 90, ox + 22, oy - 46), fill=skin)  # سر
        kd.rounded_rectangle((ox - 38, oy - 46, ox + 38, oy + 20), radius=14, fill=jersey)  # تنه
        kd.line([(ox - 34, oy - 30), (ox - 70, oy - 55)], fill=jersey, width=16)  # دست چپ بالا
        kd.line([(ox + 34, oy - 30), (ox + 70, oy - 55)], fill=jersey, width=16)  # دست راست بالا
        kd.line([(ox - 15, oy + 18), (ox - 25, oy + 70)], fill=shorts, width=18)  # پا چپ
        kd.line([(ox + 15, oy + 18), (ox + 25, oy + 70)], fill=shorts, width=18)  # پا راست

    layer = layer.filter(ImageFilter.SMOOTH)
    img.alpha_composite(layer, (int(cx - kw), int(base_y - kh * 0.55)))


def _draw_scoreboard(draw, score, streak, mode_label):
    box = (20, 20, 360, 100)
    draw.rounded_rectangle(box, radius=16, fill=(0, 0, 0, 160))
    f_title = _font(FONT_BOLD, 22)
    f_val = _font(FONT_BOLD, 30)
    draw.text((40, 28), mode_label, font=f_title, fill=(255, 255, 255))
    draw.text((40, 58), f"SCORE: {score}   BEST STREAK: {streak}", font=f_val, fill=(255, 215, 0))


def _draw_result_banner(draw, text, color):
    f = _font(FONT_BOLD, 68)
    bbox = draw.textbbox((0, 0), text, font=f)
    tw, th = bbox[2] - bbox[0], bbox[3] - bbox[1]
    x = (WIDTH - tw) / 2
    y = 480
    # سایه پشت متن برای خوانایی
    draw.rounded_rectangle((x - 30, y - 15, x + tw + 30, y + th + 25), radius=20, fill=(0, 0, 0, 150))
    draw.text((x, y), text, font=f, fill=color, stroke_width=3, stroke_fill=(0, 0, 0))


def render_penalty_scene(
    mode,             # "shoot" یا "save"
    shot_zone,        # جهت توپ: left/center/right
    keeper_zone,      # جهت دروازه‌بان: left/center/right
    result,           # "goal" یا "save"
    score,
    streak,
    filename,
):
    """صحنه نهایی پنالتی را رندر و در فایل ذخیره می‌کند."""
    img = Image.new("RGBA", (WIDTH, HEIGHT), (0, 0, 0, 255))
    draw = ImageDraw.Draw(img)

    _draw_pitch(draw, img)
    left_x, right_x, top_y, ground_y = _draw_goal(draw, img)

    # دروازه‌بان (شیرجه به سمت keeper_zone)
    _draw_keeper(img, draw, keeper_zone, left_x, right_x, ground_y, dive=(keeper_zone != "center") or result == "save")

    # موقعیت توپ: اگر گل شده، توپ داخل زاویه‌ی مقابل تور نشسته؛ اگر سیو شده، نزدیک دست دروازه‌بان
    ball_y = top_y + 90 if shot_zone != "center" else top_y + 130
    bx, by = _zone_center(shot_zone, left_x, right_x, ball_y)
    if result == "goal":
        by -= 20
    _draw_ball(img, draw, (bx, by))

    mode_label = "MODE: SHOOTOUT" if mode == "shoot" else "MODE: GOALKEEPER"
    _draw_scoreboard(draw, score, streak, mode_label)

    if result == "goal":
        if mode == "shoot":
            _draw_result_banner(draw, "GOAL !", (60, 220, 90))
        else:
            _draw_result_banner(draw, "GOAL CONCEDED", (230, 70, 70))
    else:
        if mode == "shoot":
            _draw_result_banner(draw, "SAVED", (230, 70, 70))
        else:
            _draw_result_banner(draw, "SAVE !", (60, 220, 90))

    # جهت ضربه / دروازه‌بان به انگلیسی پایین تصویر (متن فارسی در کپشن تلگرام ارسال می‌شود)
    f_small = _font(FONT_REGULAR, 20)
    info = f"SHOT: {shot_zone.upper()}      KEEPER: {keeper_zone.upper()}"
    bbox = draw.textbbox((0, 0), info, font=f_small)
    tw = bbox[2] - bbox[0]
    draw.text(((WIDTH - tw) / 2, HEIGHT - 40), info, font=f_small, fill=(255, 255, 255))

    out_path = os.path.join(ASSETS_DIR, filename)
    img.convert("RGB").save(out_path, quality=95)
    return out_path


def render_prompt_scene(mode, score, streak, filename):
    """صحنه‌ی قبل از ضربه: انتخاب جهت توسط بازیکن"""
    img = Image.new("RGBA", (WIDTH, HEIGHT), (0, 0, 0, 255))
    draw = ImageDraw.Draw(img)

    _draw_pitch(draw, img)
    left_x, right_x, top_y, ground_y = _draw_goal(draw, img)
    _draw_keeper(img, draw, "center", left_x, right_x, ground_y, dive=False)

    mode_label = "MODE: SHOOTOUT" if mode == "shoot" else "MODE: GOALKEEPER"
    _draw_scoreboard(draw, score, streak, mode_label)

    prompt = "PICK YOUR SHOT SIDE" if mode == "shoot" else "PICK YOUR DIVE SIDE"
    f = _font(FONT_BOLD, 46)
    bbox = draw.textbbox((0, 0), prompt, font=f)
    tw = bbox[2] - bbox[0]
    x, y = (WIDTH - tw) / 2, 500
    draw.rounded_rectangle((x - 30, y - 15, x + tw + 30, y + 70), radius=20, fill=(0, 0, 0, 150))
    draw.text((x, y), prompt, font=f, fill=(255, 220, 60), stroke_width=2, stroke_fill=(0, 0, 0))

    # فلش‌های راهنما روی سه ناحیه دروازه
    f_arrow = _font(FONT_BOLD, 34)
    for zone, label in zip(["left", "center", "right"], ["L", "C", "R"]):
        zx, _ = _zone_center(zone, left_x, right_x, 0)
        draw.ellipse((zx - 24, ground_y + 25, zx + 24, ground_y + 73), fill=(255, 255, 255, 230))
        bbox_l = draw.textbbox((0, 0), label, font=f_arrow)
        lw, lh = bbox_l[2] - bbox_l[0], bbox_l[3] - bbox_l[1]
        draw.text((zx - lw / 2, ground_y + 49 - lh / 2 - bbox_l[1]), label, font=f_arrow, fill=(20, 20, 20))

    out_path = os.path.join(ASSETS_DIR, filename)
    img.convert("RGB").save(out_path, quality=95)
    return out_path


def render_welcome_banner(filename="welcome.png"):
    """بنر خوش‌آمدگویی منوی اصلی"""
    img = Image.new("RGBA", (WIDTH, 450), (0, 0, 0, 255))
    draw = ImageDraw.Draw(img)
    _vertical_gradient(draw, (0, 0, WIDTH, 450), (20, 90, 24), (10, 50, 15))
    stripe_layer = Image.new("RGBA", (WIDTH, 450), (0, 0, 0, 0))
    _draw_pitch_pattern_simple(ImageDraw.Draw(stripe_layer))
    img.alpha_composite(stripe_layer)

    f_title = _font(FONT_BOLD, 60)
    f_sub = _font(FONT_REGULAR, 26)
    title = "PENALTY CHALLENGE"
    bbox = draw.textbbox((0, 0), title, font=f_title)
    tw = bbox[2] - bbox[0]
    draw.text(((WIDTH - tw) / 2, 130), title, font=f_title, fill=(255, 255, 255),
               stroke_width=4, stroke_fill=(0, 0, 0))

    sub = "Shoot. Save. Score. Compete."
    bbox2 = draw.textbbox((0, 0), sub, font=f_sub)
    tw2 = bbox2[2] - bbox2[0]
    draw.text(((WIDTH - tw2) / 2, 230), sub, font=f_sub, fill=(230, 230, 230))

    out_path = os.path.join(ASSETS_DIR, filename)
    img.convert("RGB").save(out_path, quality=95)
    return out_path


def _draw_pitch_pattern_simple(draw):
    for i in range(0, WIDTH, 100):
        draw.rectangle([i, 0, i + 50, 450], fill=(255, 255, 255, 18))


if __name__ == "__main__":
    # تست سریع تولید تصویر
    render_penalty_scene("shoot", "left", "right", "goal", score=5, streak=3, filename="test_goal.png")
    render_penalty_scene("save", "center", "center", "save", score=2, streak=1, filename="test_save.png")
    render_welcome_banner()
    print("done")
