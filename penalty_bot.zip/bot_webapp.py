# -*- coding: utf-8 -*-
"""
ربات تلگرامی چالش پنالتی — نسخه‌ی Mini App (شبیه ربات نات‌کوین)

بازی با گرافیک انیمیشنی و لمسی داخل خود تلگرام از طریق Telegram Web App
اجرا می‌شه (فایل webapp/index.html). امتیاز و رکورد هر بازیکن مستقیم
روی حساب تلگرامش (Telegram CloudStorage) ذخیره می‌شه، پس این ربات
نیازی به دیتابیس یا سرور بک‌اند جداگانه نداره.
"""

import logging
import os

from telegram import Update, KeyboardButton, ReplyKeyboardMarkup, WebAppInfo
from telegram.ext import Application, CommandHandler, ContextTypes

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# پیکربندی
# ---------------------------------------------------------------------------
BOT_TOKEN = os.environ.get("PENALTY_BOT_TOKEN", "PUT-YOUR-BOT-TOKEN-HERE")

# آدرس Mini App که روی GitHub Pages (یا هر میزبان HTTPS دیگه) گذاشتی
# مثال: https://username.github.io/penalty-webapp/
WEBAPP_URL = os.environ.get("PENALTY_WEBAPP_URL", "PUT-YOUR-GITHUB-PAGES-URL-HERE")


def game_keyboard():
    kb = [[KeyboardButton("🎮 شروع بازی", web_app=WebAppInfo(url=WEBAPP_URL))]]
    return ReplyKeyboardMarkup(kb, resize_keyboard=True)


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = (
        "🏟 <b>به چالش پنالتی خوش اومدی!</b>\n\n"
        "⚽ ضربه بزن یا 🧤 دروازه‌بانی کن، امتیازت رو بالا ببر و رکورد پیاپی بشکن.\n"
        "گرافیک کامل و انیمیشن‌دار، درست مثل یه اپ واقعی داخل تلگرام.\n\n"
        "برای شروع، دکمه‌ی زیر رو بزن 👇"
    )
    await update.message.reply_text(text, parse_mode="HTML", reply_markup=game_keyboard())


async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE):
    logger.error(f"Update {update} caused error {context.error}")


def main():
    if BOT_TOKEN == "PUT-YOUR-BOT-TOKEN-HERE":
        print("⚠️  لطفاً توکن ربات رو در متغیر محیطی PENALTY_BOT_TOKEN قرار بده یا در bot.py جایگزین کن.")
    if "PUT-YOUR-GITHUB-PAGES-URL-HERE" in WEBAPP_URL:
        print("⚠️  لطفاً آدرس GitHub Pages وب‌اپ رو در WEBAPP_URL قرار بده (باید HTTPS باشه).")

    # سازگاری با Python 3.14+: از این نسخه به بعد event loop به‌صورت خودکار
    # توی ترد اصلی ساخته نمی‌شه، پس صریحاً می‌سازیمش.
    import asyncio
    try:
        asyncio.get_event_loop()
    except RuntimeError:
        asyncio.set_event_loop(asyncio.new_event_loop())

    application = Application.builder().token(BOT_TOKEN).build()
    application.add_handler(CommandHandler("start", start))
    application.add_error_handler(error_handler)

    logger.info("ربات پنالتی (Mini App) در حال اجراست...")
    application.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
