# -*- coding: utf-8 -*-
"""
ربات تلگرامی بازی پنالتی
دو حالت: زدن پنالتی (Shootout) و گرفتن پنالتی (Goalkeeper)
امتیازدهی + لیدربورد + گرافیک تولیدشده با Pillow
"""

import logging
import os
import random
import time

from telegram import InputMediaPhoto, InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, ContextTypes

import database as db
import graphics as gfx

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# پیکربندی
# ---------------------------------------------------------------------------
BOT_TOKEN = os.environ.get("PENALTY_BOT_TOKEN", "PUT-YOUR-BOT-TOKEN-HERE")

ZONES = ["left", "center", "right"]
ZONE_FA = {"left": "چپ ⬅️", "center": "وسط ⏺️", "right": "راست ➡️"}
MODE_FA = {"shoot": "زدن پنالتی ⚽", "save": "گرفتن پنالتی 🧤"}

# ---------------------------------------------------------------------------
# کیبوردها
# ---------------------------------------------------------------------------

def main_menu_kb():
    kb = [
        [InlineKeyboardButton("⚽ زدن پنالتی", callback_data="play:shoot")],
        [InlineKeyboardButton("🧤 گرفتن پنالتی", callback_data="play:save")],
        [InlineKeyboardButton("📊 آمار من", callback_data="stats"),
         InlineKeyboardButton("🏆 برترین‌ها", callback_data="lb_menu")],
        [InlineKeyboardButton("ℹ️ راهنما", callback_data="help")],
    ]
    return InlineKeyboardMarkup(kb)


def direction_kb(mode):
    kb = [[
        InlineKeyboardButton("⬅️ چپ", callback_data=f"shot:{mode}:left"),
        InlineKeyboardButton("⏺️ وسط", callback_data=f"shot:{mode}:center"),
        InlineKeyboardButton("➡️ راست", callback_data=f"shot:{mode}:right"),
    ], [
        InlineKeyboardButton("🏠 منوی اصلی", callback_data="home"),
    ]]
    return InlineKeyboardMarkup(kb)


def result_kb(mode):
    kb = [
        [InlineKeyboardButton("🔁 ضربه بعدی", callback_data=f"play:{mode}")],
        [InlineKeyboardButton("🔄 تغییر حالت", callback_data="home"),
         InlineKeyboardButton("📊 آمار من", callback_data="stats")],
    ]
    return InlineKeyboardMarkup(kb)


def leaderboard_menu_kb():
    kb = [
        [InlineKeyboardButton("⚽ برترین‌های زدن پنالتی", callback_data="lb:shoot")],
        [InlineKeyboardButton("🧤 برترین‌های گرفتن پنالتی", callback_data="lb:save")],
        [InlineKeyboardButton("🏆 جدول کلی", callback_data="lb:total")],
        [InlineKeyboardButton("🏠 منوی اصلی", callback_data="home")],
    ]
    return InlineKeyboardMarkup(kb)


def back_home_kb():
    return InlineKeyboardMarkup([[InlineKeyboardButton("🏠 منوی اصلی", callback_data="home")]])


# ---------------------------------------------------------------------------
# ابزار کمکی
# ---------------------------------------------------------------------------

def display_name(user):
    if user.username:
        return f"@{user.username}"
    return user.first_name or "بازیکن"


async def send_photo_or_edit(query, photo_path, caption, reply_markup):
    """پیام را با عکس جدید ویرایش می‌کند (یا در صورت خطا پیام جدید می‌فرستد)."""
    try:
        with open(photo_path, "rb") as f:
            await query.edit_message_media(
                media=InputMediaPhoto(f, caption=caption, parse_mode="HTML"),
                reply_markup=reply_markup,
            )
    except Exception as e:
        logger.warning(f"edit_message_media failed, sending new message: {e}")
        with open(photo_path, "rb") as f:
            await query.message.reply_photo(photo=f, caption=caption, parse_mode="HTML",
                                              reply_markup=reply_markup)


# ---------------------------------------------------------------------------
# هندلرها
# ---------------------------------------------------------------------------

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    banner = os.path.join(gfx.ASSETS_DIR, "welcome.png")
    if not os.path.exists(banner):
        gfx.render_welcome_banner()

    caption = (
        "🏟 <b>به بازی چالش پنالتی خوش اومدی!</b>\n\n"
        "⚽ <b>زدن پنالتی:</b> جهت شوتت رو انتخاب کن و امیدوار باش دروازه‌بان جهتت رو حدس نزنه!\n"
        "🧤 <b>گرفتن پنالتی:</b> جهت شیرجه‌ات رو انتخاب کن و امیدوار باش با ضربه‌ی حریف یکی بشه!\n\n"
        "هر ضربه‌ی موفق ۱ امتیاز داره. رکورد پیاپی‌ت رو هم ثبت می‌کنیم 🔥\n\n"
        "یکی از حالت‌های زیر رو انتخاب کن:"
    )
    with open(banner, "rb") as f:
        await update.message.reply_photo(photo=f, caption=caption, parse_mode="HTML",
                                          reply_markup=main_menu_kb())


async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    data = query.data
    user = update.effective_user

    if data == "home":
        banner = os.path.join(gfx.ASSETS_DIR, "welcome.png")
        caption = (
            "🏟 <b>منوی اصلی</b>\n\n"
            "یکی از حالت‌های بازی رو انتخاب کن:"
        )
        await send_photo_or_edit(query, banner, caption, main_menu_kb())
        return

    if data == "help":
        banner = os.path.join(gfx.ASSETS_DIR, "welcome.png")
        caption = (
            "ℹ️ <b>راهنمای بازی</b>\n\n"
            "⚽ <b>زدن پنالتی:</b> تو ضربه‌زن هستی. یکی از سه جهت (چپ / وسط / راست) رو برای شوت انتخاب می‌کنی. "
            "دروازه‌بان به‌صورت تصادفی یک طرف شیرجه می‌زنه. اگه جهتت با اون فرق داشته باشه = گل!\n\n"
            "🧤 <b>گرفتن پنالتی:</b> تو دروازه‌بانی. یکی از سه جهت رو برای شیرجه انتخاب می‌کنی. "
            "حریف به‌صورت تصادفی یک طرف شوت می‌زنه. اگه جهتت با اون یکی باشه = سیو!\n\n"
            "هر برد ۱ امتیاز داره و رکورد پیاپی‌هات هم ذخیره می‌شه. موفق باشی! 🔥"
        )
        await send_photo_or_edit(query, banner, caption, back_home_kb())
        return

    if data.startswith("play:"):
        mode = data.split(":")[1]
        stats = db.get_player_stats(user.id)
        score = stats[f"{mode}_score"]
        # رکورد پیاپی فعلی رو نداریم مستقیم، از بهترین استفاده می‌کنیم برای نمایش لحظه‌ی شروع
        streak = stats[f"{mode}_best_streak"]
        fname = f"prompt_{user.id}.png"
        path = gfx.render_prompt_scene(mode, score, streak, fname)
        caption = (
            f"🎯 <b>{MODE_FA[mode]}</b>\n\n"
            + ("جهت ضربه‌ات رو انتخاب کن 👇" if mode == "shoot" else "جهت شیرجه‌ات رو انتخاب کن 👇")
        )
        await send_photo_or_edit(query, path, caption, direction_kb(mode))
        return

    if data.startswith("shot:"):
        _, mode, player_zone = data.split(":")
        opp_zone = random.choice(ZONES)

        if mode == "shoot":
            won = player_zone != opp_zone
            result = "goal" if won else "save"
            shot_zone, keeper_zone = player_zone, opp_zone
        else:
            won = player_zone == opp_zone
            result = "save" if won else "goal"
            shot_zone, keeper_zone = opp_zone, player_zone

        score, played, cur_streak, best_streak = db.record_round(
            user.id, user.username, user.first_name, mode, won
        )

        fname = f"result_{user.id}_{int(time.time()*1000)}.png"
        path = gfx.render_penalty_scene(mode, shot_zone, keeper_zone, result, score, cur_streak, fname)

        if won:
            headline = "🎉 آفرین! امتیاز گرفتی!"
        else:
            headline = "😔 این دفعه نشد، دوباره تلاش کن!"

        caption = (
            f"{headline}\n\n"
            f"🎯 حالت: {MODE_FA[mode]}\n"
            f"📈 امتیاز کل: <b>{score}</b>   |   تعداد بازی: {played}\n"
            f"🔥 رکورد پیاپی فعلی: {cur_streak}   |   بهترین رکورد: {best_streak}"
        )
        await send_photo_or_edit(query, path, caption, result_kb(mode))

        # پاکسازی فایل‌های موقت برای جلوگیری از پر شدن دیسک
        try:
            old_files = sorted(
                [f for f in os.listdir(gfx.ASSETS_DIR) if f.startswith(f"result_{user.id}_")]
            )
            for old in old_files[:-3]:
                os.remove(os.path.join(gfx.ASSETS_DIR, old))
        except Exception:
            pass
        return

    if data == "stats":
        s = db.get_player_stats(user.id)
        shoot_pct = (s["shoot_score"] / s["shoot_played"] * 100) if s["shoot_played"] else 0
        save_pct = (s["save_score"] / s["save_played"] * 100) if s["save_played"] else 0
        caption = (
            f"📊 <b>آمار بازی {display_name(user)}</b>\n\n"
            f"⚽ <b>زدن پنالتی</b>\n"
            f"  گل‌ها: {s['shoot_score']} از {s['shoot_played']} ضربه ({shoot_pct:.0f}٪)\n"
            f"  بهترین رکورد پیاپی: {s['shoot_best_streak']}\n\n"
            f"🧤 <b>گرفتن پنالتی</b>\n"
            f"  سیوها: {s['save_score']} از {s['save_played']} ضربه ({save_pct:.0f}٪)\n"
            f"  بهترین رکورد پیاپی: {s['save_best_streak']}\n\n"
            f"🏆 مجموع امتیاز: <b>{s['shoot_score'] + s['save_score']}</b>"
        )
        banner = os.path.join(gfx.ASSETS_DIR, "welcome.png")
        await send_photo_or_edit(query, banner, caption, back_home_kb())
        return

    if data == "lb_menu":
        banner = os.path.join(gfx.ASSETS_DIR, "welcome.png")
        await send_photo_or_edit(query, banner, "🏆 <b>کدوم جدول رو می‌خوای ببینی؟</b>", leaderboard_menu_kb())
        return

    if data.startswith("lb:"):
        kind = data.split(":")[1]
        banner = os.path.join(gfx.ASSETS_DIR, "welcome.png")

        if kind == "total":
            rows = db.get_combined_leaderboard(10)
            title = "🏆 جدول کلی برترین‌ها"
        else:
            rows = db.get_leaderboard(kind, 10)
            title = f"🏆 برترین‌های {MODE_FA[kind]}"

        if not rows:
            caption = f"{title}\n\nهنوز کسی بازی نکرده! اولین نفر باش 🚀"
        else:
            lines = [f"{title}\n"]
            medals = ["🥇", "🥈", "🥉"]
            for i, (username, first_name, score, played) in enumerate(rows):
                medal = medals[i] if i < 3 else f"{i+1}."
                name = f"@{username}" if username else (first_name or "بازیکن")
                lines.append(f"{medal} {name} — {score} امتیاز ({played} بازی)")
            caption = "\n".join(lines)

        await send_photo_or_edit(query, banner, caption, leaderboard_menu_kb())
        return


async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE):
    logger.error(f"Update {update} caused error {context.error}")


def main():
    if BOT_TOKEN == "PUT-YOUR-BOT-TOKEN-HERE":
        print("⚠️  لطفاً توکن ربات رو در متغیر محیطی PENALTY_BOT_TOKEN قرار بده یا در bot.py جایگزین کن.")

    # سازگاری با Python 3.14+: از پایتون 3.14 دیگه event loop به‌صورت خودکار
    # توی ترد اصلی ساخته نمی‌شه، پس صریحاً می‌سازیمش.
    import asyncio
    try:
        asyncio.get_event_loop()
    except RuntimeError:
        asyncio.set_event_loop(asyncio.new_event_loop())

    db.init_db()
    if not os.path.exists(os.path.join(gfx.ASSETS_DIR, "welcome.png")):
        gfx.render_welcome_banner()

    application = Application.builder().token(BOT_TOKEN).build()

    application.add_handler(CommandHandler("start", start))
    application.add_handler(CallbackQueryHandler(button_handler))
    application.add_error_handler(error_handler)

    logger.info("ربات پنالتی در حال اجراست...")
    application.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
